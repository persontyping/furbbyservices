import { action } from '@uibakery/data';

function submitContactForm() {
  return action('submitContactForm', 'HTTP', {
    datasourceName: 'httpApi',
    options: {
      method: 'POST',
      url: 'https://your-endpoint.example.com/contact',
      bodyType: 'object',
      headers: {
        'Content-Type': 'application/json',
      },
      body: `{
        name: {{params?.name}},
        email: {{params?.email}},
        message: {{params?.message}},
      }`,
    },
  });
}

export default submitContactForm;
