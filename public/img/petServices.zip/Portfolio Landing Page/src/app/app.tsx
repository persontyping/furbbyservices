'use client';

import '@/index.css';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/app/components/Header';
import Hero from '@/app/components/Hero';
import Gallery from '@/app/components/Gallery';
import Contact from '@/app/components/Contact';
import Footer from '@/app/components/Footer';
import BackToTop from '@/app/components/BackToTop';
import { useTheme } from '@/app/hooks/useTheme';

function App() {
  const [theme, toggleTheme] = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header theme={theme} onToggleTheme={toggleTheme} />
      <main>
        <Hero />
        <Gallery />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
      <Toaster />
    </div>
  );
}

export default App;
