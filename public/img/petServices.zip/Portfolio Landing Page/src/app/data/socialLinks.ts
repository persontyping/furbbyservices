export interface SocialLink {
  name: 'instagram' | 'facebook' | 'linkedin';
  href: string;
}

export const socialLinks: SocialLink[] = [
  { name: 'instagram', href: 'https://instagram.com/your-petsitting-handle' },
  { name: 'facebook', href: 'https://facebook.com/your-petsitting-page' },
  { name: 'linkedin', href: 'https://linkedin.com/in/your-handle' },
];
