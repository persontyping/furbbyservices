export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
}

export const galleryItems: GalleryItem[] = [
  { id: '1', title: 'Morning Walkies', category: 'Dog Walking', image: '/assets/images/default.svg' },
  { id: '2', title: 'Backyard Playtime', category: 'Pet Sitting', image: '/assets/images/default.svg' },
  { id: '3', title: 'Overnight Stay', category: 'Boarding', image: '/assets/images/default.svg' },
  { id: '4', title: 'Cat Check-In', category: 'Cat Sitting', image: '/assets/images/default.svg' },
  { id: '5', title: 'Puppy Playdate', category: 'Dog Walking', image: '/assets/images/default.svg' },
  { id: '6', title: 'Cozy Nap Time', category: 'Boarding', image: '/assets/images/default.svg' },
  { id: '7', title: 'Park Adventures', category: 'Dog Walking', image: '/assets/images/default.svg' },
  { id: '8', title: 'Treat Time', category: 'Pet Sitting', image: '/assets/images/default.svg' },
];
