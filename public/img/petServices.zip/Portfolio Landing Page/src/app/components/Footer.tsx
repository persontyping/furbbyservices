import SocialIcons from '@/app/components/SocialIcons';

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border py-10">
      <div className="container flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
        <p className="text-sm text-muted-foreground">
          © {year} Happy Tails Pet Sitting. All rights reserved.
        </p>
        <SocialIcons />
      </div>
    </footer>
  );
}

export default Footer;
