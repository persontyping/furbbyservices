import { Moon, Sun } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

interface ThemeToggleProps {
  theme: 'light' | 'dark';
  onToggle: () => void;
}

function ThemeToggle({ theme, onToggle }: ThemeToggleProps) {
  const isDark = theme === 'dark';

  return (
    <div className="flex items-center gap-2">
      <Sun className="h-4 w-4 text-sun" />
      <Switch checked={isDark} onCheckedChange={onToggle} aria-label="Toggle dark mode" />
      <Moon className="h-4 w-4 text-sky" />
    </div>
  );
}

export default ThemeToggle;
