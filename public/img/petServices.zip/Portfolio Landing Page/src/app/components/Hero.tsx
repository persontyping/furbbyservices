import { ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MASCOT_URL =
  'https://locmttqklzjqzzbowmrp.supabase.co/storage/v1/object/sign/img/bill-logo.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV80ZjliY2ZlNy1jYzRjLTQ0N2YtYjk0MC0wZTAwMGY1MDU3OTIiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJpbWcvYmlsbC1sb2dvLnBuZyIsInNjb3BlIjoiZG93bmxvYWQiLCJpYXQiOjE3ODc1Nzc4NDEsImV4cCI6MjAwODMyOTg0MX0.QUgZPgrX52K1KHwytOqjDEnXT2IKH-W7Xze5P0yZAf4';

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div
        className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-coral/20 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-sky/20 blur-3xl"
        aria-hidden
      />

      <div className="container relative grid gap-10 py-24 sm:py-32 lg:grid-cols-2 lg:items-center lg:gap-12">
        <div className="flex flex-col items-start gap-6">
          <span className="rounded-full bg-pink/10 px-4 py-1 text-sm font-medium text-pink">
            Trusted Pet Sitting &amp; Dog Walking
          </span>

          <h1 className="max-w-2xl text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            Loving care for your
            <span className="text-coral"> furry </span>
            family members.
          </h1>

          <p className="max-w-xl text-lg text-muted-foreground">
            Hi, I'm Jordan — a passionate pet sitter offering walks, drop-in visits, and overnight
            stays. Take a look at some happy moments below, or get in touch to book a visit.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button asChild size="lg" className="bg-coral text-white hover:bg-coral/90">
              <a href="#gallery">See the gallery</a>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="#contact">Book a visit</a>
            </Button>
          </div>

          <a
            href="#gallery"
            aria-label="Scroll to gallery"
            className="mt-10 flex items-center gap-2 self-center text-sm text-muted-foreground transition-colors hover:text-foreground sm:self-start"
          >
            <ArrowDown className="h-4 w-4 animate-bounce" />
            Scroll to explore
          </a>
        </div>

        <div className="flex justify-center lg:justify-end">
          <div className="relative flex h-[420px] w-[420px] items-center justify-center rounded-full bg-sun/15">
            <img
              src={MASCOT_URL}
              alt="Happy Tails Pet Sitting mascot, a fluffy Pomeranian"
              className="h-[400px] w-[400px] object-contain drop-shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
