import { useState } from 'react';
import { Expand } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { galleryItems, type GalleryItem } from '@/app/data/galleryItems';

const accentBorders = ['border-coral', 'border-sky', 'border-pink', 'border-leaf', 'border-sun'];

function Gallery() {
  const [selected, setSelected] = useState<GalleryItem | null>(null);

  return (
    <section id="gallery" className="border-t border-border bg-secondary/40 py-20">
      <div className="container">
        <div className="mb-10 flex flex-col gap-2">
          <span className="text-sm font-semibold uppercase tracking-wider text-sky">Happy moments</span>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Gallery</h2>
          <p className="max-w-xl text-muted-foreground">
            A peek into walks, playtime, and cozy stays with the pets I care for.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {galleryItems.map((item, index) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelected(item)}
              className={`group relative aspect-square overflow-hidden rounded-xl border-2 bg-card ${
                accentBorders[index % accentBorders.length]
              } text-left transition-transform hover:-translate-y-1`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 flex flex-col justify-end gap-1 bg-gradient-to-t from-black/70 via-black/0 to-black/0 p-3 opacity-0 transition-opacity group-hover:opacity-100">
                <span className="text-xs font-medium uppercase tracking-wide text-white/80">
                  {item.category}
                </span>
                <span className="text-sm font-semibold text-white">{item.title}</span>
              </div>
              <span className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white opacity-0 transition-opacity group-hover:opacity-100">
                <Expand className="h-4 w-4" />
              </span>
            </button>
          ))}
        </div>
      </div>

      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-2xl">
          {selected && (
            <div className="flex flex-col gap-4">
              <DialogTitle>{selected.title}</DialogTitle>
              <img
                src={selected.image}
                alt={selected.title}
                className="w-full rounded-lg border border-border object-cover"
              />
              <span className="text-sm font-medium uppercase tracking-wide text-coral">
                {selected.category}
              </span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default Gallery;
