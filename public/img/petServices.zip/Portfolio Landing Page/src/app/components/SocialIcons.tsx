import { Instagram, Facebook, Linkedin } from 'lucide-react';
import { socialLinks } from '@/app/data/socialLinks';

const iconMap = {
  instagram: Instagram,
  facebook: Facebook,
  linkedin: Linkedin,
};

function SocialIcons({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {socialLinks.map((link) => {
        const Icon = iconMap[link.name];
        return (
          <a
            key={link.name}
            href={link.href}
            target="_blank"
            rel="noreferrer"
            aria-label={link.name}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-foreground/70 transition-colors hover:border-coral hover:text-coral"
          >
            <Icon className="h-4 w-4" />
          </a>
        );
      })}
    </div>
  );
}

export default SocialIcons;
