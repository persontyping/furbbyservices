import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import ContactForm from '@/app/components/ContactForm';

function Contact() {
  return (
    <section id="contact" className="py-20">
      <div className="container grid gap-10 lg:grid-cols-2 lg:items-center">
        <div className="flex flex-col gap-3">
          <span className="text-sm font-semibold uppercase tracking-wider text-leaf">Get in touch</span>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Book a visit</h2>
          <p className="max-w-md text-muted-foreground">
            Ready to schedule a walk, drop-in visit, or overnight stay? Fill out the form and I'll
            get back to you to confirm the details.
          </p>
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Send a message</CardTitle>
          </CardHeader>
          <CardContent>
            <ContactForm />
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

export default Contact;
